package com.fintech;

public class FornecedorCredor {
	int Id;
	String nome;
	String descricao;
	int cprCnpj;
}
