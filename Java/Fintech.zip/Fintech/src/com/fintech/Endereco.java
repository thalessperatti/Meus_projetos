package com.fintech;

public class Endereco {
	int cep;
	String logradouro;
	String endereco;
	int numero;
	String complemento;
	String bairro;
	String cidade;
	String estado;
}
