package com.fintech;

public class ContaBancaria {
	int id;
	String nome;
	String descricao;
	String tipoConta;
	double saldo;
	int agencia;
	int nrConta;
	int digitoConta;
	
	
	public ContaBancaria() {
		
	}
	
	public ContaBancaria(int id, String nome, String descricao, String tipoConta, double saldo, int agencia,
			int nrConta, int digitoConta) {
		
	}

}
