package com.fintech;

import java.util.Date;

public class Usuario {
	int Id;
	String nome;
	String sobrenome;
	Date dataNascimento;
	int cpf;
}
