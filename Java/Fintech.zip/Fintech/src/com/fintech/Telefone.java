package com.fintech;

public class Telefone {
	int Id;
	int prefixo;
	int numero;
	String tipo;
}
