package com.fintech;

public class ValidacaoUsuario {
	boolean validacao;

}
