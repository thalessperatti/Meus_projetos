package com.fintech;

import java.util.Date;

public class Transacao {
	int Id;
	Date data;
	float valor;
}
