package com.fintech;

public class TipoLancamento {
	int Id;
	String nome;
	String descricao;
	String tipoLancamento;
}
